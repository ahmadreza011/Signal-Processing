n1 = -200 : 200;
y1 = cos(0.02*pi*n1 + pi/4);
plot(n1, y1)
n = 0 : 100;
y = cos(0.02*pi*n + pi/4);
z = y + 0.5 * wgn(1, length(n), 1, 'linear');
figure
plot(n, z)
r = cos(0.02*pi*(n-20) + pi/4) + 0.5 * wgn(1, length(n), 1, 'linear');
figure
plot(n, r)

figure
plot(xcorr(r, y))
[c1,lags1] = xcorr(cos(0.02*pi*(n-20) + pi/4), y);
stem(lags1,c1)
[c,lags] = xcorr(r, y);
figure
stem(lags,c)
