T = 1/8000;
t = 0 : T : 1;
omega = 2*pi*1000;   %change this for other parts
xt = sin(omega*t);
n = 0 : 8000;
xn = sin(omega*n*T);
stem(0:49, xn(1:50))
hold on
plot(0:49, xt(1:50))
hold off
xr = spline(n*T, xn, t);
figure
X = fftshift(fft(xr));
plot(-4000:4000, abs(X))
sound(xn)