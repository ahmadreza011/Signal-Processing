bvd = load("BVD.mat");
output = bvd.data;
plot(output.time, output.signal)
new_signal = awgn(output.signal, 20);
figure
plot(output.time, new_signal)