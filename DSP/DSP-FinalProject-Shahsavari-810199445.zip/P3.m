A = imread("cat.jpg");
B = imread("horse.jpg");
imshow(A)
figure
imshow(B)
f1 = fft2(A);
f2 = fft2(B);
f1_abs = abs(fftshift(f1));
f1_phase = angle(fftshift(f1));
f2_abs = abs(fftshift(f2));
f2_phase = angle(fftshift(f2));
m = max(size(A,1), size(B,1));
n = max(size(A,2), size(B,2));
F11 = fft2(A,m,n);
F22 = fft2(B,m,n);
f11_abs = abs((F11));
f11_phase = angle((F11));
f22_abs = abs((F22));
f22_phase = angle((F22));
image1 = ifft2(f11_abs .* exp(1i*f22_phase),m,n);
image2 = ifft2(f22_abs .* exp(1i*f11_phase),m,n);
figure
imshow(uint8(image2))
%imshow(real(image2))
%imshow(angle(image2))
figure
imshow(uint8(image1))
%imshow(real(image1))
%imshow(angle(image1))