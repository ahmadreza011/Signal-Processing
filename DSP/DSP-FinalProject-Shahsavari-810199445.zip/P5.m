A = imread("Lenna.png");
imshow(A)
I = rgb2gray(A);
figure
subplot(2,2,3)
imshow(I)
title("original gray image")

%G1 = fspecial('gaussian', size2, sigma)
%B = imgaussfilt(I,20);
%image = rescale(image, 0, 255);
%image1 = mat2gray(image);

size = 512;
sigma = 10;        %change this for other parts
[X, Y] = meshgrid(-size/2:size/2-1, -size/2:size/2-1);
G = exp((-1/(2*(sigma^2)))*(X.^2 + Y.^2)); 
subplot(2,2,1)
imshow(G)
title("2D filter")
subplot(2,2,2)
surf(G)
title("3D filter")
F = fftshift(fft2(I)).*G;
image = abs(ifft2(F));

subplot(2,2,4)
imshow(uint8(image))
title("filtered image")