function  coef = corr_2d(pic1, pic2)
    % [rows, columns] = size(pic1);
     
%      pic1_sqrd_sum = 0;
%      pic2_sqrd_sum = 0;

%      for i = 1:rows
%          for j = 1:columns
%              numenator = numenator + pic1(i,j)*pic2(i,j);
%              pic1_sqrd_sum = pic1_sqrd_sum + pic1(i,j)^2;
%              pic2_sqrd_sum = pic2_sqrd_sum + pic2(i,j)^2;
%          end
%      end
% %      disp(numenator == pic1*pic2)
%      disp(class(pic2_sqrd_sum))
%      denomenator = pic1_sqrd_sum * pic2_sqrd_sum;
%      denomenator = sqrt(denomenator);

    numenator = sum(sum(pic1.*pic2));
    denomenator = sqrt(sum(sum(pic1.*pic1))*sum(sum(pic2.*pic2)));
     
     coef = numenator/denomenator;
end