clc
close all;
clear;

ic = select_image();
board = select_image();

gray_ic = rgb_to_gray(ic);
gray_board = rgb_to_gray(board);
figure, imshow(gray_ic);
figure, imshow(gray_board);
gray_ic_rotated = imrotate(gray_ic, 180);

matrix = corr_matrix(gray_board,gray_ic);
figure,plot_surface(matrix);
matrix_rotated =  corr_matrix(gray_board,gray_ic_rotated);

% figure,plot_surface(matrix_rotated);

M_cell = {matrix; matrix_rotated};

result = plot_box(board, gray_ic, M_cell);





function pic = select_image()
    [file, path] = uigetfile({'*.png;*.jpg'}, 'Select an image');
    pic_path = [path,file];
    pic = imread(pic_path);
end

function grayscale = rgb_to_gray(pic)
    grayscale = 0.299 * pic(:,:,1) + 0.578 * pic(:,:,2) + 0.114 * pic(:,:,3);
end


function  coef = corr_2d(pic1, pic2)
  %   [rows, columns] = size(pic1);
     
%      pic1_sqrd_sum = 0;
%      pic2_sqrd_sum = 0;

%      for i = 1:rows
%          for j = 1:columns
%              numenator = numenator + pic1(i,j)*pic2(i,j);
%              pic1_sqrd_sum = pic1_sqrd_sum + pic1(i,j)^2;
%              pic2_sqrd_sum = pic2_sqrd_sum + pic2(i,j)^2;
%          end
%      end
% %      disp(numenator == pic1*pic2)
%      disp(class(pic2_sqrd_sum))
%      denomenator = pic1_sqrd_sum * pic2_sqrd_sum;
%      denomenator = sqrt(denomenator);

    numenator = sum(sum(pic1.*pic2));
    denomenator = sqrt(sum(sum(pic1.*pic1))*sum(sum(pic2.*pic2)));
     
     coef = numenator/denomenator;
end

function M = corr_matrix(PCB, IC)
    [PCB_row, PCB_col] = size(PCB); 
    [IC_row, IC_col] = size(IC); 
    IC = double(IC);
    IC = IC - mean2(IC);
    
    M = zeros(PCB_row - IC_row+1, PCB_col - IC_col+1);

    for i=1:(PCB_row - IC_row + 1)
        for j=1:(PCB_col - IC_col + 1)
            PCB_cropped = double(PCB(i:i + IC_row - 1, j:j + IC_col - 1));
            PCB_cropped = PCB_cropped - mean2(PCB_cropped);
            M(i,j) = corr_2d(IC, PCB_cropped);
%             disp(M(i,j) == corr2(IC,PCB_cropped));
        end 
    end
end

function  plot_surface(matrix)
    surf(matrix);
end

function result = plot_box(PCB, IC, M_cell) 
    [IC_row, IC_col] = size(IC); 
    threshold = 0.6;

    figure, imshow(PCB);
        hold on;
        for l=1:length(M_cell)
            [rows, cols] = find(cell2mat(M_cell(l)) > threshold);
            for k=1:length(rows)
                rectangle('Position',[cols(k) rows(k) IC_col IC_row],'EdgeColor','b','LineWidth',2);
            end
        end
        F = getframe(gcf);
        result = frame2im(F);
end

