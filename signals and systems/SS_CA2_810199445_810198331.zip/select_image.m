function pic = select_image()
    [file, path] = uigetfile({'*.png;*.jpg'}, 'Select an image');
    pic_path = [path,file];
    pic = imread(pic_path);
end