function  plot_surface(matrix)
    surf(matrix);
end