function grayscale = rgb_to_gray(pic)
    grayscale = 0.299 * pic(:,:,1) + 0.578 * pic(:,:,2) + 0.114 * pic(:,:,3);
end