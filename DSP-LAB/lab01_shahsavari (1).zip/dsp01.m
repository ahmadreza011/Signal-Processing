[y,fs] = audioread("Recording.m4a");
ts = 1/fs;
output = Expander(y(:,2), 2);
audiowrite("output.wav", output.', fs)

function [y] = Expander(x, L)
    y = zeros(1, (length(x) - 1) * L+1);
    for i = -L*(length(x) - 1)/2 : L*(length(x) - 1)/2
        if(mod(i, L) == 0)
            y(i + L*(length(x) - 1)/2 + 1) = x(i/L + (length(x) - 1)/2 + 1);
        end
    end
end

function [y] = Compressor(x, M) 
  %  y = x(1 : M : end);
   y = zeros(1, (length(x) - 1)/M+1);
   for i = -(length(x) - 1)/(2*M) : (length(x) - 1)/(2*M)
       y(i + (length(x) - 1)/(2*M) + 1) = x(i*M + (length(x) - 1)/2 + 1);
   end  
end