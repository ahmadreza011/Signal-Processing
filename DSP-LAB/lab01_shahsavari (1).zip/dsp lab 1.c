#include <stdio.h>
#include <stdlib.h>
#define SIZE 5

double *expander(double input[], int L) {
   // int output[L * SIZE] = {0};
    double *output = (double*) malloc(L* SIZE * sizeof(double));
    for(int i = 0; i < L * SIZE; i++) {
        output[i] = 0;
    }
    for(int i = -L * (SIZE - 1) / 2 ; i <= L * (SIZE - 1) / 2; i++) { 
        if(i % L == 0) {
            output[i + (L * (SIZE - 1) / 2) ] = input[i / L + ((SIZE - 1) / 2)];
        }
    }
    return output;
}

double *compressor(double input[], int M) {
    double *output = (double*) malloc(((SIZE - 1)/M + 1) * sizeof(double));
    for(int i = -(SIZE - 1)/(2*M); i <= (SIZE - 1)/(2*M); i++) {
        output[i + (SIZE - 1)/(2*M)] = input[i * M + (SIZE - 1) / 2];
    }
    return output;
}

int main() {
    double input[SIZE];
    printf("enter input array : ");
    for(int i = 0; i < SIZE; i++) {
        scanf("%lf", &input[i]);
    }
    printf("type C for compress and E for expand: ");
    char mode;
    scanf(" %c", &mode);  // space ghable %c fekr konam moheme
    if(mode == 'E') {
        printf("enter L: ");
        int L;
        scanf("%d", &L);
        double* output = expander(input, L);
        printf("output array : ");
        for(int i = 0; i < L * SIZE; i++) { 
            printf("%lf , ", *(output + i));
        }
    }
    else if(mode == 'C') {
        printf("enter M: ");
        int M;
        scanf("%d", &M);
        double* output = compressor(input, M);
        printf("output array : ");
        for(int i = 0; i < ((SIZE - 1)/M + 1); i++) { 
            printf("%lf , ", *(output + i));
        }
    }
    /*FILE* file = fopen("myFile.txt", "r");
    double array[SIZE];  // for our input signal, SIZE equals to 209919
    int i = 0;
    double input1;
    while(fscanf(file,"%lf", &input1)) {
        array[i] = input1;
        //printf(" %lf \n", array[i]);
        i++;
    }
    fclose(file);
    double* output2 = compressor(array, 2);  // do what we want to do with the input signal
    FILE *fp;
    fp=fopen("output.txt","w+");
    for(int i=0; i<sizeof(output2)/sizeof(output2[1]); i++) {
        fprintf(fp,"%e\n",output2[i]);
    }
    fclose(fp);   */
}

