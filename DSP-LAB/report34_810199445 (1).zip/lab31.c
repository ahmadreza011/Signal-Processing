#include "Complex.h"
#include "Complex.c"
#include "fft.c"
#include <math.h>
#define N 1024

int main() {
    
    complex sine1[N];
    complex sine2[N];
    complex sine3[N];
    float freq1 = 2000.0;
    float freq2 = 4000.0;
    float freq3 = 5000.0;
    float w1 = 2 * PI * freq1;
    float w2 = 2 * PI * freq2;
    float w3 = 2 * PI * freq3;
    float fs1 = 16000.00;      //change to desired sampling frequency
    for(int i = 0; i < N; i++) {
        sine1[i].x = sin(w1 * i / fs1);
        sine1[i].y = 0;
    }
    for(int i = 0; i < N; i++) {
        sine2[i].x = sin(w2 * i / fs1);
        sine2[i].y = 0;
    }
    for(int i = 0; i < N; i++) {
        sine3[i].x = sin(w3 * i / fs1);
        sine3[i].y = 0;
    }
    FILE *fp = fopen("Output1.txt", "w+"); 
        if (fp == NULL) { 
            printf("Failed to open file\n"); 
        } 
   fft(sine1, N, 1);
   double abs1[N];
     for(int i = 0; i < N; i++) {
        abs1[i] = ccabs(sine1[i]);
        fprintf(fp, "%lf ", abs1[i]);
     }
    fclose(fp);

    FILE *fp1 = fopen("Output2.txt", "w+"); 
        if (fp1 == NULL) { 
            printf("Failed to open file\n"); 
        } 
    fft(sine2, 1024, 1);
    double abs2[N];
     for(int i = 0; i < N; i++) {
        abs2[i] = ccabs(sine2[i]);
        fprintf(fp1, "%lf ", abs2[i]);
     }
    fclose(fp1);
     
    FILE *fp2 = fopen("Output3.txt", "w+"); 
        if (fp2 == NULL) { 
            printf("Failed to open file\n"); 
        } 
    fft(sine3, 1024, 1);
    double abs3[N];
     for(int i = 0; i < N; i++) {
        abs3[i] = ccabs(sine3[i]);
        fprintf(fp2, "%lf ", abs3[i]);
     }
    fclose(fp2);

}