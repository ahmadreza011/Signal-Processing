#include "Complex.h"
#include "Complex.c"
#include "fft.c"
#include <math.h>
#define N 1024
#define L 8 
#define length 1024*64

void func1(double* input,int i, complex* ping, complex* pong) {
    double a[N];
    double b[N];
    for(int j = 0; j < N; j++) {
            a[j] = 0;
            b[j] = 0;
    } 
    for(int j = 0; j < N; j++)
            a[j] = input[i * N + j];

    for(int j = N; j < 2 * N; j++)
        b[j - N] = input[i * N + j];
        
    for(int j = 0; j < N; j++) {
        ping[j].x = a[j];
        ping[j].y = b[j];
        pong[j].x = a[j];
        pong[j].y = b[j];
    }
}

void pwr_spectrum(double* input,double* spectrum ,complex* ping, complex* pong) {
    double temp[N / 2 + 1] = { 0 };
    for(int i = 0; i < length / (2 * N); i++) {
        func1(input, i, ping, pong);
        fft(pong, N, 1);

        for(int k = 0; k < N / 2 + 1; k++)
            temp[k] += (ccabs(pong[k]) * ccabs(pong[k]) + ccabs(pong[N - 1 - k]) * ccabs(pong[N - 1 - k])) / 2;
            
        if((i - 1) % L == 0)
            for(int j = 0; j < N / 2 + 1; j++) {
                spectrum[j] += temp[j] / (L * N);
                temp[j] = 0;
            }
    }
}

void rect(double* out) {
    /*for(int k = 0; k < floor(2*length / N); k++) { 
        for(int i = 0; i < 256;i++)
            out[i+(512*k)] = 1;
        for(int i = 256; i < 512; i++)
            out[i+(512*k)] = 0;
    }*/
    for(int k = 0; k < floor(length / N); k++) { 
        for(int i = 0; i < 512;i++)
            out[i+(1024*k)] = 1;
        for(int i = 512; i < 1024; i++)
            out[i+(1024*k)] = 0;
    }
}

void sine(double* out) {
    for(int i = 0; i < length; i++)
        out[i] = 10000 * sin(2 * PI * 100 * i / 512);
}

void cosine(double* out) {
    for(int i = 0; i < length; i++)
        out[i] = 10000 * cos(2 * PI * 100 * i / 1024);
}

int main() {
        complex ping[N];
        complex pong[N];
        double a[N];
        double b[N];
        double input[length] = { 0 };
        double spectrum[N / 2 + 1] = { 0 };
        
        //cosine(input);
        sine(input);
        //rect(input);

        pwr_spectrum(input, spectrum , ping, pong);

        FILE *fp = fopen("Output.txt", "w+"); 
        if (fp == NULL) { 
            printf("Failed to open file\n"); 
        }

        for(int i = 0; i < N / 2 + 1; i++) {
            fprintf(fp, "%lf ", spectrum[i]);
        }
     fclose(fp);
}