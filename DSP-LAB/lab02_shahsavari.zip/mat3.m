%fs = 10000;  %for part 2
fs = 100;     % for c code
t = 0 : 1/fs : 60;
ts = 1/fs;
variance = 1;
mean = 0;    %change mean for different inputs 
%noise = mean + sqrt(variance).*randn(1,600001);   %for part 2
noise = mean + sqrt(variance).*randn(1,6001);   %for c code
sec1 = filter(G(1)*SOS(1,1:3), SOS(1,4:6) , noise);
sec2 = filter(G(2)*SOS(2,1:3), SOS(2,4:6) , sec1);
sec3 = filter(G(3)*SOS(3,1:3), SOS(3,4:6) , sec2);
%plot(t, sec3)
FF = fftshift(fft(sec3));
plot(-fs/2:fs/length(sec3):fs/2-fs/length(sec3), abs(FF))

