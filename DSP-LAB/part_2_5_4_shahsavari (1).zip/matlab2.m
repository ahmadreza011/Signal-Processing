[x, fs] = audioread("Mefsin.wav");
% sound(x, fs)
m = fftshift(fft(x));
%f =-fs/2:fs/length(x):fs/2-fs/length(x);  plotting signal in [-fs/2:fs/2]
f = 0 : fs/length(x) : fs/2 - fs/length(x); 
plot(f, abs(m(end/2 + 1 : end)))
xlabel('f');
ylabel("|X(f)|");
[MAX, noise_index] = max(abs(m(end/2 + 1 : end)));
noise_freq = f(noise_index);
theta = (pi * noise_freq) /(fs/2);
filter_coefs = [1, -2 * cos(theta), 1];
output = filter(filter_coefs, 1, x);
output_F = fftshift(fft(output));
figure()
plot(f,abs(output_F(end/2 + 1 : end)));
xlabel('f');
ylabel("|Y(f)|");
sound(output, fs)
audiowrite("Output.wav", output, fs)